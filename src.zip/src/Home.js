import React, { Component } from 'react';
import './Home.css';
import Header from './Components/Header/Header';
import Routes from './Components/Routes/Routes';
import TestForm from './Components/TestForm/TestForm';
// import ListingCard from './Components/ListingCard/ListingCard';
// import data from './assets/property_data.json';
// import { BrowserRouter} from 'react-router-dom';
import { BrowserRouter} from 'react-router-dom';
import ListingCard from './Components/ListingCard/ListingCard';
import axios from 'axios';

class Home extends Component {

    // componentDidMount () {
    //     axios.get( 'http://localhost/reactjs/index.php')
    //     .then( response => {
    //         console.log( response );
    //     } )
    //     .catch (error => {
    //         // console.log(error);
    //         this.setState({error:true})
    //     });
    // }

    render() {

        return (
            <BrowserRouter>
                <div className="Home">
                    <Header />
                    <Routes />
                    <ListingCard />
                    {/* <TestForm /> */}
                    {/* <ListingCard /> */}
                    {/* <ul>{
						// console.log(data);
						data.map((movie,key) => {
							return <li key={key}>{movie.title["en"]}</li>;
						})
						}
					</ul> */}
                </div>
            </BrowserRouter>
        );
    }
}

export default Home;
