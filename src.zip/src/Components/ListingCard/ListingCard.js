import React, { Component } from 'react';
import './ListingCard.css';
// import listingData from './assets/property_data.json';

class ListingCard extends Component {
	constructor(props) {
		super(props);
		this.state = {
			"listings": ""
		};
	}

	componentDidMount() {
		// const data ={
		//     purpose:this.state.purpose,
		//     location:this.state.location,
		//     property_type:this.state.property_type,
		//     property_price:this.state.property_price
		// }
		// fetch('http://localhost/reactjs/', {method: "GET",})
		// .then(resposne => {
		//     console.log(resposne);
		// });
	}

	render() {
		return (
			<section>
				<ul>
					<li className="blocks ls-mn sticky_ads">
						<a className="block">
							<div className="left img-slider white-arrow design-1 to-rent">
								<div className="slider-con main_dimension">
									{/* <img src="" alt=""> */}
									<span className="video-icon"></span>
									<div className="controls  video-control">
										<div className="search-imgcount left" title="نمایش تمام صفحه">
											<span className="right">
												۱۱
												<i className="ihome-camera"></i>
											</span>

											<span className="right">
												۱
												<i className="ihome-movie-symbol-of-video-camera"></i>
											</span>
										</div>
										<ul class="loc-controls right">
											<li className="left fav"></li>
										</ul>
									</div>
								</div>
							</div>

							<div class="right slider_content to-rent ">
								<div class="c-logo right">
									<span class="helper"></span>
									{/* <img src="https://cdn.ihome.ir/ih_agents_images/xxs/3154-0_3154.jpg" alt="املاک شکوه زعفرانیه(زعفرانیه)"> */}
								</div>
								<div class="price" data-price="" data-area="1507" data-cur-area="Sq. M.">
									<span class="label">اجاره:</span>۸,۰۰۰,۰۰۰<span class="currency">تومان </span>
								</div>
								<div class="full">
									<div class="deposit" data-price="" data-area="1507" data-cur-area="Sq. M.">
										<span class="label">رهن:</span>۱۰۰,۰۰۰,۰۰۰<span class="currency">تومان </span>
									</div>
								</div>
								<div class="location iswrp ">
									<span>زعفرانیه</span>
								</div>
								<ul class="left slider_pinfo">
									<li class="left">
										<i class="ihome-arrows"></i>
										۱۴۰ متر مربع
										<div class="meta-tooltip">متراژ</div>
									</li>
								</ul>
								<div class="clearfix"></div>
								<div class="loc-info left">
									<span class="title-maps" title="اجاره یک واحد 140 متری از برج  در زعفرانیه">
										<div class="title-wrap">
											<h2 class="title">
												اجاره یک واحد 140 متری از برج  در زعفرانیه
											</h2>
										</div>
									</span>
									<p class="">مسکن شکوه زعفرانیهداخل برجفول امکانات۱۴۰متر۳خواب سالن پذیرایی بزرگ دیدکوه آشپزخانه اوپن mdf لابی سرایداری استخرسوناجکوزی دسترسی خوب</p>
								</div>
							</div>
							<ul class="listing-cta">
								<li>
									<div class="cta-tooltip">ایمیل</div>
									<button class="ghost-btn">
										ایمیل
                        				<i class="ihome-message"></i>
									</button>
								</li>
								<li>
									<div class="cta-tooltip">تماس</div>
									<button class="ghost-btn call" value="تماس">
										تماس
                            			<i class="ihome-call"></i>
									</button>
                                </li>
            				</ul>
						</a>
					</li>
				</ul>
			</section>
				)
			};
		}
												
export default ListingCard;