import React from 'react';
import './Agent.css';

const Agent = () => {
    return (
        // console.log("Listing Card Render");
        <h1>Agent Component/Page</h1>
    )
};

export default Agent;