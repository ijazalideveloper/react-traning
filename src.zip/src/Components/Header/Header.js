import React from 'react';
import './Header.css';
import { Link } from 'react-router-dom';

const Header = () => {
    return (
        <header className="container">
            <Link className="logo hs left" title="ihome.ir - ایران و تهران" to={'/'}> </Link>
            <nav className="right">
                <ul>
                    <li className="left"><Link className="link-l" title="آژانسهای املاک و مستغلات" to={'/agent' }>مشاوران املاک</Link></li>
                    <li className="left"><a id="other_language_link" data-lang="en" title="English" href="javascript:void(0)" className="link-l arabic">English</a></li>
                    {/* <li className="icon-settings link-l-dd hs left user_top_extras">
                        <div class="dropdown dd-hide">
                            <div class="content">
                                <ul>
                                    <li data-width="400" data-role="popup" onclick="event.preventDefault(); event.stopPropagation(); popup(this, '#currency_popup');"> تغییر واحد پولی </li>
                                </ul>
                            </div>
                        </div>
                    </li> */}
                    <li className="left m0">
                        <a href="javascript:void(0)" className="login">ورود</a>
                    </li>
                </ul>
            </nav>
            <div className="clearfix"></div>
        </header>
    )
};

export default Header;