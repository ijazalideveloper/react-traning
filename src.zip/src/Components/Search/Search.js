import React , {Component} from 'react';
import './Search.css';
import axios from 'axios';
// import data from './assets/property_data.json';

class Search extends Component {
    listingCard = {}; 
    constructor(prop){
        super(prop)
        this.state = {
            purpose : '',
            location : '',
            property_type : '',
            property_price : '',
        }
        this.onChangeShowValue = this.onChangeShowValue.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    onChangeShowValue = (name,e) => {
        let uservalue = e.target.value;
        console.log(uservalue);
        this.setState({
            [name]: e.target.value
        });
    }

    
    handleSubmit = (e) => {
        console.log(this.state);
        e.preventDefault();
        const data = this.state;
        console.log(data);
        axios.get( 'http://localhost/reactjs/index.php', {
            params: {
                ...data
            }
        })
        .then( response => {
            console.log( response );
        } )
        .catch (error => {
            // console.log(error);
            this.setState({error:true})
        });
    }

    render(){
        return (
            <form onSubmit = {this.handleSubmit}>
                <div className="search_bg left">
                    <div className="container">
                        <div className="purpose left margin-right">
                            <select name="purpose" value={this.state.purpose} onChange={(e) => this.onChangeShowValue('purpose',e)} >
                                <option>Select</option>
                                <option value={1}>For Sale</option>
                                <option value={2}>For Rent</option>
                            </select>
                        </div>
                        <div className="location left margin-right">
                            <input type="text" name="location" value={this.state.location} onChange={(e) => this.onChangeShowValue('location',e)} />
                        </div>
                        <div className="propoerty_type left margin-right">
                            <select name="property_type" value={this.state.property_type} onChange={(e) => this.onChangeShowValue('property_type',e)} > 
                                <option value={1}>Residential</option>
                                <option value={4}>Apartments</option>
                                <option value={2}>Villas</option>
                                <option value={3}>Residential Plots</option>
                                <option value={4}>Houses</option>
                            </select>
                        </div>
                        <div className="propoerty_price left margin-right">
                            <input type="text" name="property_price" value={this.state.property_price} onChange={(e) => this.onChangeShowValue('property_price',e)} />
                        </div>
                        <div className="submit_btn left margin-right">
                            <button name="search_sbmt">Submit</button>
                        </div>
                    </div>
                </div>
            </form>
        )
    };
}

export default Search;