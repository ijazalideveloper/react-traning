import React from 'react';
import Search from '../Search/Search';
import Agent from '../Agent/Agent';
import { Route, Switch } from 'react-router-dom';

const Routes = () => {
    return (
            <Switch>
                <Route exact path='/' component={Search} />
                <Route path='/agent' component={Agent} />
                <Route path='/agent' component={Search} />
            </Switch>
    )
};

export default Routes;